// Client ID and API key from the Developer Console
var CLIENT_ID = '1099247811989-693013rvanemq18nmhl9tf8555m8q0it.apps.googleusercontent.com';
var API_KEY = 'AIzaSyCmQo6PrIuUd3YnSDRYNbgjAJb6PYcagB4';

// Array of API discovery doc URLs for APIs used by the quickstart
var DISCOVERY_DOCS = ["https://sheets.googleapis.com/$discovery/rest?version=v4"];

// Authorization scopes required by the API; multiple scopes can be
// included, separated by scopes.
var SCOPES = "https://www.googleapis.com/auth/spreadsheets.readonly";

var firstname = document.getElementById('first-name');
var lastname = document.getElementById('last-name');
var email = document.getElementById('email');

function handleClientLoad() {
  firstname.text = 'boo'
  gapi.load('client:auth2', initClient);
}

// Initializes API client library and attempts sign-in
function initClient() {
  gapi.client.init({
    apiKey: API_KEY,
    clientId: CLIENT_ID,
    discoveryDocs: DISCOVERY_DOCS,
    scope: SCOPES
  }).then(function() {
    // Listen for sign-in state changes.
    gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);

    // Hangle the initial sign-in state.
    updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
    gapi.auth2.getAuthInstance().signIn();
  });
}

// Called when the sign in state changes
function updateSigninStatus(isSignedIn) {
  if (isSignedIn) {
    firstname.text = 'nice'
  }
}
