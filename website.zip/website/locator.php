

<html>
	<head>
		<title></title>
		<script src="/jquery.js" type="text/javascript"></script>
		<script src="/locator_script.js" type="text/javascript"></script>
		<style>
			body {background-color: rgb(51, 51, 51);}
			h1{color: Snow;
					font-size: 40px;
					background-color: rgb(64, 64, 64);}
			h2 {font-size: 20px;
					color: rgb(179, 179, 179)}
			h3 {font-size: 20px;
					color: CadetBlue}
			p  {color: grey;}
		</style>
		<style type="text/css">a {text-decoration: none; color: white;}</style>
	</head>
	<body>

		<h1 align='center' id='head'><a href='/index.php'>PARANOIA</a></h1>

    <h1 align='center' id='first-name'><a href='/index.php'>noone</a></h1>
    <h1 align='center' id='last-name'><a href='/index.php'>noone</a></h1>
    <h1 align='center' id='email'><a href='/index.php'>no@gmail.com</a></h1>

		<p align='center'>
		<h3 align = 'center'><a href="/leaderboards.php" hspace=20><font color=#8f9b9e>Leaderboards&emsp;</font></a>
			<a href="/rules.php" hspace=20><font color=#8f9b9e>Rules&emsp;</font></a>
		<a href="/announcements.php" hspace=20><font color=#8f9b9e>Announcements</font></a></h3>
    <h3 align = 'center'><a href="https://goo.gl/forms/O26iqcx8NF9ieQY32" hspace=20><font color=#66ddff>Elimination Form&emsp;</font></a>
    <a href="/locator.php" hspace=20><font color=#a8babf>Agent Database</font></a></h3>
  </p>
	</body>
</html>
