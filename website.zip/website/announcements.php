

<html>
	<head>
		<title></title>
		<script src="/jquery.js" type="text/javascript"></script>
		<script src="/script.js" type="text/javascript"></script>
		<style>
			body {background-color: rgb(51, 51, 51);}
			h1{color: Snow;
					font-size: 40px;
					background-color: rgb(64, 64, 64);}
			h2 {font-size: 20px;
					color: rgb(179, 179, 179)}
			h3 {font-size: 20px;
					color: CadetBlue}
			p  {color: grey;}
		</style>
		<style type="text/css">a {text-decoration: none; color: white;}</style>
	</head>
	<body>

		<h1 align='center' id='head'><a href='/index.php'>PARANOIA</a></h1>

    <center><a class="twitter-timeline" data-lang="en" data-width="600" data-height="600" data-theme="dark" data-link-color="#879ec4" href="https://twitter.com/AreYouParanoid?ref_src=twsrc%5Etfw">Tweets by AreYouParanoid</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

    <p align='center'>
		<h3 align = 'center'><a href="/leaderboards.php" hspace=20><font color=#8f9b9e>Leaderboards&emsp;</font></a>
			<a href="/rules.php" hspace=20><font color=#8f9b9e>Rules&emsp;</font></a>
		<a href="/announcements.php" hspace=20><font color=#8f9b9e>Announcements</font></a></h3>
    <h3 align = 'center'><a href="https://goo.gl/forms/O26iqcx8NF9ieQY32" hspace=20><font color=#66ddff>Elimination Form&emsp;</font></a>
    <a href="https://docs.google.com/spreadsheets/d/1ndpIGS8XWhHn84MWfjxlm6yR0COYSnLJlBkI3zt4cyY/edit#gid=0" hspace=20><font color=#a8babf>Agent Database</font></a></h3>
  </p>
	</body>
</html>
